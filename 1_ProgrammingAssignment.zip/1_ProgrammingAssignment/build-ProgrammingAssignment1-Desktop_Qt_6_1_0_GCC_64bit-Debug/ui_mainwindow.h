/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.1.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *LiftingArea;
    QLabel *label;
    QPlainTextEdit *matrixLiftingOutput;
    QVBoxLayout *MultiArea;
    QLabel *label_2;
    QPlainTextEdit *matrixMultiplicationOutput;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout_4;
    QLabel *label_5;
    QLineEdit *RedInput;
    QLabel *label_4;
    QLineEdit *GreenInput;
    QLabel *label_3;
    QLineEdit *BlueInput;
    QPushButton *pushButtonCustom;
    QVBoxLayout *verticalLayout_3;
    QLabel *MinRgb;
    QLineEdit *MinRgbInput;
    QVBoxLayout *verticalLayout;
    QLabel *MaxRgb;
    QLineEdit *MaxRgbInput;
    QPushButton *pushButton;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 10, 761, 541));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        LiftingArea = new QVBoxLayout();
        LiftingArea->setObjectName(QString::fromUtf8("LiftingArea"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        LiftingArea->addWidget(label);

        matrixLiftingOutput = new QPlainTextEdit(layoutWidget);
        matrixLiftingOutput->setObjectName(QString::fromUtf8("matrixLiftingOutput"));

        LiftingArea->addWidget(matrixLiftingOutput);


        horizontalLayout->addLayout(LiftingArea);

        MultiArea = new QVBoxLayout();
        MultiArea->setObjectName(QString::fromUtf8("MultiArea"));
        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        MultiArea->addWidget(label_2);

        matrixMultiplicationOutput = new QPlainTextEdit(layoutWidget);
        matrixMultiplicationOutput->setObjectName(QString::fromUtf8("matrixMultiplicationOutput"));

        MultiArea->addWidget(matrixMultiplicationOutput);


        horizontalLayout->addLayout(MultiArea);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setSizeConstraint(QLayout::SetDefaultConstraint);
        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_4->addWidget(label_5);

        RedInput = new QLineEdit(layoutWidget);
        RedInput->setObjectName(QString::fromUtf8("RedInput"));

        verticalLayout_4->addWidget(RedInput);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        verticalLayout_4->addWidget(label_4);

        GreenInput = new QLineEdit(layoutWidget);
        GreenInput->setObjectName(QString::fromUtf8("GreenInput"));

        verticalLayout_4->addWidget(GreenInput);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        verticalLayout_4->addWidget(label_3);

        BlueInput = new QLineEdit(layoutWidget);
        BlueInput->setObjectName(QString::fromUtf8("BlueInput"));

        verticalLayout_4->addWidget(BlueInput);


        verticalLayout_2->addLayout(verticalLayout_4);

        pushButtonCustom = new QPushButton(layoutWidget);
        pushButtonCustom->setObjectName(QString::fromUtf8("pushButtonCustom"));

        verticalLayout_2->addWidget(pushButtonCustom);

        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setSizeConstraint(QLayout::SetMinimumSize);
        MinRgb = new QLabel(layoutWidget);
        MinRgb->setObjectName(QString::fromUtf8("MinRgb"));

        verticalLayout_3->addWidget(MinRgb);

        MinRgbInput = new QLineEdit(layoutWidget);
        MinRgbInput->setObjectName(QString::fromUtf8("MinRgbInput"));

        verticalLayout_3->addWidget(MinRgbInput);


        verticalLayout_2->addLayout(verticalLayout_3);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetMinimumSize);
        MaxRgb = new QLabel(layoutWidget);
        MaxRgb->setObjectName(QString::fromUtf8("MaxRgb"));

        verticalLayout->addWidget(MaxRgb);

        MaxRgbInput = new QLineEdit(layoutWidget);
        MaxRgbInput->setObjectName(QString::fromUtf8("MaxRgbInput"));

        verticalLayout->addWidget(MaxRgbInput);


        verticalLayout_2->addLayout(verticalLayout);

        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        verticalLayout_2->addWidget(pushButton);


        horizontalLayout->addLayout(verticalLayout_2);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Matrix Lifting", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Matrix Multiplication", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "Red Value", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Green Value", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Blue Value", nullptr));
        pushButtonCustom->setText(QCoreApplication::translate("MainWindow", "PushButton", nullptr));
        MinRgb->setText(QCoreApplication::translate("MainWindow", "Min RGB values(0 min)", nullptr));
        MaxRgb->setText(QCoreApplication::translate("MainWindow", "Max RGB values (255 max)", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Run with Min / Max RGB values", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
