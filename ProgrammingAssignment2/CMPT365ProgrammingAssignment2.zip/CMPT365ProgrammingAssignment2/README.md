# Running the program

1. In a terminal, execute `make all` in the assignment directory.
2. Execute `./test {Huffman input text file} {LZW input text file}`. If no arguments are given, the program will prompt with how to run the executable.
3. To clean, enter `make clean`.