# Running the program

- Note, this runs in Linux only or systems with make

1. In a terminal, execute `make all` in the assignment directory.
2. Execute `./test {Arithmetic Encoding Input Text File} {Discrete Cosine Transformation Input Text File}`. If no arguments are given, the program will prompt with how to run the executable.
3. To clean, enter `make clean`.